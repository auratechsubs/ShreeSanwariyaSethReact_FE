import React from 'react'
import heroImage from "@/assets/hero-dubai.jpg";

function Banner() {
  return (
   <>
    <section className="relative h-96 flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img src={heroImage} alt="About" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-black/60" />
        </div>
        <div className="relative z-10 text-center text-white">
          <h1 className="text-5xl font-bold mb-4 animate-fade-in">
            About Shree Sanwariya Seth & Travels
          </h1>
          <p className="text-xl text-white/90">Your Trusted Partner for UAE Adventures</p>
        </div>
      </section>
   
   </>
  )
}

export default Banner
