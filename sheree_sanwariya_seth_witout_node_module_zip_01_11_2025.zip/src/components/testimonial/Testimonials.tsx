import React from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Star } from 'lucide-react'
import { useQuery } from '@tanstack/react-query'

function Testimonials() {
  // ✅ Fetch function using fetch()
  const fetchTestimonials = async () => {
    const response = await fetch('http://127.0.0.1:8888/testimonial/')
    if (!response.ok) {
      throw new Error('Failed to fetch testimonials')
    }
    const data = await response.json()
    return data.data // only return `data` array
  }

  // ✅ React Query
  const { data: testimonials = [], isLoading, isError } = useQuery({
    queryKey: ['testimonials'],
    queryFn: fetchTestimonials,
  })

  // ✅ Loading State
  if (isLoading)
    return (
      <section className="py-20 text-center">
        <p className="text-lg">Loading testimonials...</p>
      </section>
    )

  // ✅ Error State
  if (isError)
    return (
      <section className="py-20 text-center">
        <p className="text-lg text-red-500">Failed to load testimonials 😢</p>
      </section>
    )

  // ✅ Main UI
  return (
    <section className="py-20 gradient-section">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4">What Our Travelers Say</h2>
          <p className="text-lg text-muted-foreground">
            Trusted by thousands of happy Indian travelers
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial: any) => (
            <Card key={testimonial.testimonial_id} className="shadow-card">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-primary text-primary" />
                  ))}
                </div>

                {/* 💬 Message */}
                <p className="text-muted-foreground mb-4 italic">
                  {testimonial.message.replace(/^"|"$/g, '')}
                </p>

                {/* 👤 User Info */}
                <div>
                  <p className="font-semibold">{testimonial.name}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.city}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Testimonials
