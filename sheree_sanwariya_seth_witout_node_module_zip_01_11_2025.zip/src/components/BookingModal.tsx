import { useState } from 'react';
import { X, Phone, Mail, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  itemType: 'package' | 'hotel' | 'service';
  itemName: string;
  itemPrice?: string;
}

const BookingModal = ({ isOpen, onClose, itemType, itemName, itemPrice }: BookingModalProps) => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    date: '',
    adults: '2',
    children: '0',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Format message for WhatsApp
    const whatsappMessage = `
*New ${itemType.charAt(0).toUpperCase() + itemType.slice(1)} Inquiry*

📦 ${itemType.charAt(0).toUpperCase() + itemType.slice(1)}: ${itemName}
${itemPrice ? `💰 Price: ${itemPrice}` : ''}

👤 Name: ${formData.name}
📧 Email: ${formData.email}
📱 Phone: ${formData.phone}
📅 Travel Date: ${formData.date}
👥 Adults: ${formData.adults} | Children: ${formData.children}

💬 Message: ${formData.message}
    `.trim();

    // Send to WhatsApp
    const whatsappUrl = `https://wa.me/971123456789?text=${encodeURIComponent(whatsappMessage)}`;
    window.open(whatsappUrl, '_blank');

    // Send email (mailto link)
    const emailSubject = `${itemType.charAt(0).toUpperCase() + itemType.slice(1)} Inquiry: ${itemName}`;
    const emailBody = whatsappMessage.replace(/\*/g, '').replace(/📦|💰|👤|📧|📱|📅|👥|💬/g, '');
    const mailtoUrl = `mailto:info@ssswtc.com?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
    window.location.href = mailtoUrl;

    toast({
      title: "Inquiry Sent!",
      description: "We'll contact you shortly via WhatsApp and Email.",
    });

    onClose();
    setFormData({ name: '', email: '', phone: '', date: '', adults: '2', children: '0', message: '' });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 animate-fade-in">
      <div className="bg-card rounded-lg shadow-hover max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-card border-b border-border p-6 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">Book {itemName}</h2>
            {itemPrice && <p className="text-primary font-semibold">{itemPrice}</p>}
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-secondary rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">Full Name *</Label>
              <Input
                id="name"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Enter your name"
              />
            </div>
            <div>
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="your@email.com"
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="phone">Phone Number *</Label>
              <Input
                id="phone"
                type="tel"
                required
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="+91 XXXXXXXXXX"
              />
            </div>
            <div>
              <Label htmlFor="date">Travel Date *</Label>
              <Input
                id="date"
                type="date"
                required
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="adults">Adults</Label>
              <Input
                id="adults"
                type="number"
                min="1"
                value={formData.adults}
                onChange={(e) => setFormData({ ...formData, adults: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="children">Children</Label>
              <Input
                id="children"
                type="number"
                min="0"
                value={formData.children}
                onChange={(e) => setFormData({ ...formData, children: e.target.value })}
              />
            </div>
          </div>

          <div>
            <Label htmlFor="message">Special Requests (Optional)</Label>
            <Textarea
              id="message"
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              placeholder="Any special requirements or questions..."
              rows={4}
            />
          </div>

          <div className="flex gap-3 pt-4">
            <Button type="submit" className="flex-1 gradient-hero">
              <MessageCircle className="w-4 h-4 mr-2" />
              Send Inquiry
            </Button>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
          </div>

          <p className="text-xs text-muted-foreground text-center">
            Your inquiry will be sent via WhatsApp and Email. We'll respond within 24 hours.
          </p>
        </form>
      </div>
    </div>
  );
};

export default BookingModal;
