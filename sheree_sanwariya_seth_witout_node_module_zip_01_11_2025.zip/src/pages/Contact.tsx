import { useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useGlobalContext } from '@/Contaxt/UseGlobelcontaxt';
import Loader from '@/components/Helper/Loader';
import SectionLoader from '@/components/Helper/Section_loader';
import Faq from '@/components/Faq/Faq';
import Banner from '@/components/Banner/Banner';

const Contact = () => {
  const { toast } = useToast();
  const {contactData , contactLoading} = useGlobalContext()
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    destination: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: 'Message Sent!',
      description: 'Thank you for contacting us. We will get back to you within 24 hours.',
    });
    setFormData({ name: '', email: '', phone: '', destination: '', message: '' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

   const contactInfo = contactData
    ? [
      {
        title: contactData.ContactUs_Address1_head,
        icon: MapPin,
        details: [contactData.ContactUs_Address1],
      },
        {
          title: contactData.ContactUs_mobile_number_header,
          icon: Phone,
          details: [
            contactData.ContactUs_Mobile_Number_1,
            contactData.ContactUs_Mobile_Number_2,
          ],
        },
        {
          title: contactData.ContactUs_Emailid_header,
          icon: Mail,
          details: [contactData.ContactUs_EMAIL_ID],
        },
        {
          title: contactData.Working_Hours_header,
          icon: Mail,
          details: [contactData.Working_Hours_Time],
        },
      ]
    : [];

  return (
    <div className="min-h-screen pt-20 bg-background">

      {/* <Banner/> */}
     
      {
        contactLoading ? (
          <SectionLoader text="Loading Contact data"/>
         ):(


      <section className="gradient-section py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl font-bold mb-4 animate-fade-in">{contactData?.ContactUs_Name}</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            {contactData?.ContactUs_description}
          </p>
        </div>
      </section>
    )
 }
      {/* Contact Info Cards */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          
         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
  {contactLoading ? (
    <SectionLoader text="Loading Contact data..." height="250px" />
  ) : (
    contactInfo.map((info, index) => (
      <Card
        key={info.title}
        className="shadow-card hover:shadow-hover transition-all duration-300"
      >
        <CardContent className="p-6 text-center">
          <div className="w-12 h-12 rounded-full gradient-hero mx-auto mb-4 flex items-center justify-center">
            <info.icon className="w-6 h-6 text-white" />
          </div>
          <h3 className="font-bold mb-3">{info.title}</h3>
          {info.details.map((detail, idx) => (
            <p key={idx} className="text-sm text-muted-foreground mb-1">
              {detail}
            </p>
          ))}
        </CardContent>
      </Card>
    ))
  )}
</div>


          {/* Contact Form & Map */}
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Form */}
            <Card className="shadow-card">
              <CardContent className="p-8">
                <h2 className="text-3xl font-bold mb-6">Send Us a Message</h2>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium mb-2">Full Name *</label>
                    <Input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="Enter your full name"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Email Address *</label>
                    <Input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="your.email@example.com"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Phone Number *</label>
                    <Input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      placeholder="+91 98765 43210"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Preferred Destination</label>
                    <Input
                      type="text"
                      name="destination"
                      value={formData.destination}
                      onChange={handleChange}
                      placeholder="e.g., Dubai, Abu Dhabi"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Your Message *</label>
                    <Textarea
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      placeholder="Tell us about your travel plans, questions, or requirements..."
                      rows={5}
                      required
                    />
                  </div>

                  <Button type="submit" className="w-full gradient-hero">
                    <Send className="w-4 h-4 mr-2" />
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Map & Additional Info */}
            <div className="space-y-6">
              <Card className="shadow-card overflow-hidden">
                <CardContent className="p-0">
                  <div className="w-full h-80 bg-secondary">
                    <iframe
                      src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d462560.6828164258!2d54.947545!3d25.076022!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f43496ad9c645%3A0xbde66e5084295162!2sDubai%20-%20United%20Arab%20Emirates!5e0!3m2!1sen!2s!4v1234567890"
                      width="100%"
                      height="100%"
                      style={{ border: 0 }}
                      allowFullScreen
                      loading="lazy"
                      referrerPolicy="no-referrer-when-downgrade"
                    ></iframe>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-card gradient-hero">
                <CardContent className="p-8 text-white">
                  <h3 className="text-2xl font-bold mb-4">Why Contact Us?</h3>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <div className="w-1.5 h-1.5 rounded-full bg-white mr-3 mt-2" />
                      <span>Free consultation for UAE travel planning</span>
                    </li>
                    <li className="flex items-start">
                      <div className="w-1.5 h-1.5 rounded-full bg-white mr-3 mt-2" />
                      <span>Customized packages based on your budget</span>
                    </li>
                    <li className="flex items-start">
                      <div className="w-1.5 h-1.5 rounded-full bg-white mr-3 mt-2" />
                      <span>Expert guidance in Hindi, English & more</span>
                    </li>
                    <li className="flex items-start">
                      <div className="w-1.5 h-1.5 rounded-full bg-white mr-3 mt-2" />
                      <span>24/7 customer support throughout your trip</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="shadow-card">
                <CardContent className="p-6">
                  <h3 className="font-bold mb-3">Quick Response Guaranteed</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    We typically respond to all inquiries within 2-4 hours during business hours. 
                    For urgent matters, please call our hotline directly.
                  </p>
                  <Button className="w-full gradient-hero">
                    <Phone className="w-4 h-4 mr-2" />
                    Call Now
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
      

      {/* FAQ Section */}
       <Faq/>
      
    </div>
  );
};

export default Contact;
